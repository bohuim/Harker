import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import java.io.*;
import java.util.*;

public class WordGameDisplay implements ActionListener
{
	private JFrame frame;
	private boolean buttonPressed;
	private JTextField guessField;
	private JTextArea textArea;

	public WordGameDisplay()
	{
		frame = new JFrame();
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(new BoxLayout(frame.getContentPane(), BoxLayout.PAGE_AXIS));

		guessField = new JTextField(40);
		guessField.addActionListener(this);
		frame.getContentPane().add(guessField);

		textArea = new JTextArea(40, 40);
		textArea.setEditable(false);
		JScrollPane scrollPane = new JScrollPane(textArea);
		frame.getContentPane().add(scrollPane);

		guessField.requestFocusInWindow();

		frame.pack();
		frame.setVisible(true);
	}

	public void setTitle(String title)
	{
		frame.setTitle(title);
	}

	public String getGuess()
	{
		buttonPressed = false;
		while (!buttonPressed)
		{
			try
			{
				Thread.sleep(1);
			}
			catch(InterruptedException e)
			{
			}
		}
		String guess = guessField.getText();
		guessField.selectAll();
		return guess;
	}

	public void actionPerformed(ActionEvent event)
	{
		buttonPressed = true;
	}

	public void setText(String text)
	{
		textArea.setText(text);
	}

	public ArrayList<String> loadWords(String file)
	{
		try
		{
			BufferedReader in = new BufferedReader(new FileReader(file));
			String line = in.readLine();
			ArrayList<String> words = new ArrayList<String>();
			while (line != null)
			{
				words.add(line);
				line = in.readLine();
			}
			in.close();
			return words;
		}
		catch(IOException e)
		{
			throw new IllegalArgumentException(e.toString());
		}
	}
}