import java.io.*;
import java.util.*;

public class FileUtil
{
	public static ArrayList<String> loadFile(String fileName)
	{
		try
		{
			BufferedReader in = new BufferedReader(new FileReader(fileName));
			String line = in.readLine();
			ArrayList<String> lines = new ArrayList<String>();
			while (line != null)
			{
				lines.add(line);
				line = in.readLine();
			}
			in.close();

			return lines;
		}
		catch(IOException e)
		{
			throw new RuntimeException(e);
		}
	}

	public static void saveFile(String fileName, ArrayList<String> content)
	{
		try
		{
			PrintWriter out = new PrintWriter(new FileWriter(fileName), true);
			for (String line : content)
				out.println(line);
			out.close();
		}
		catch(IOException e)
		{
			throw new RuntimeException(e);
		}
	}
}