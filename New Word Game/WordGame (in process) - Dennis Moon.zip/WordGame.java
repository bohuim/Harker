import java.util.ArrayList;


public class WordGame
{
    private WordGameDisplay display;
    private FileUtil file;
    
    private ArrayList<String> dictionary;
    
    public WordGame()
    {
        display = new WordGameDisplay();
        file = new FileUtil();
        
        dictionary = file.loadFile("/Google Drive/Programming/Java/New Word Game/words.txt");
    }
    
    /**
     * Method: dictionaryIndex(word)
     * Usage: int index = dictionaryIndex(word);
     * -----------------------------------------
     * uses binary search to find the given word, but returns -1 
     * if word is not found
     * @param word - to find
     * @return index of that word in the dictionary
     */
    public int dictionaryIndex(String word)
    {
        int index = -1;
        int first = 0;
        int last = dictionary.size()-1;
        
        while ((last-first)>=0)
        {
            int middle = first + (last-first)/2;
            int compare = word.compareTo(dictionary.get(middle));
            
            if ((compare==0 || last==first) && word.equals(dictionary.get(middle)))
            {
                index = middle;
                last = -1;
                first = 0;
            }
            else if (compare < 0)
                last = middle-1;
            else
                first = middle+1;
        }
        
        return index;
    }
    
    /** 
     * Method: echo()
     * Usage: game.echo();
     * ----------------------------
     * the echo game method called
     */
    public void echo()
    {
        display.setTitle("The Echo Game");
        
        int submitCount = 1;
        String history = "Echo Game" + "\n" + "Please Enter a Word" + "\n";
        display.setText(history);
        
        while (true)
        {
            String userInput = display.getGuess();
            
            int index = dictionaryIndex(userInput);
            
            if (index != -1)
                history = history + submitCount + ". " + "\"" + userInput + "\"" + " is the "+ (index+1) +"th word of the dictionary!" + "\n" + "  Enter another word" + "\n";
            else 
                history = history + submitCount + ". " + "\"" + userInput + "\"" + " is not a word!" + "\n" + "  Enter another word" + "\n";

            display.setText(history);            
            submitCount++;
        }
    }
    
    
}
