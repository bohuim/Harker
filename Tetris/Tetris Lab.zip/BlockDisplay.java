import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.border.*;

/**
 * Display class of the tetris game: 
 * contains the frame, and various panels to show the main, hold and next grids
 * along with the score, level, and the panel borders
 * 
 * @version 10/26/12 - basic main grid is painted through a method
 * @version 10/31/12 - hold and 5 next grids added, along with various borders and visual enhancements
 * @version 11/1/12 - tetrads look 3D, score and level labels added
 *
 * @author Dennis Moon
 */
public class BlockDisplay implements KeyListener 
{
	private static final Color BACKGROUND = Color.BLACK;

	private MyBoundedGrid<Block> board;
	private JPanel[][] grid;
	private JPanel mainPanel;
	
	private MyBoundedGrid<Block> holdBoard;
	private JPanel[][] holdGrid;
	private JPanel holdPanel;
	private JLabel holdLabel;
	
	private MyBoundedGrid<Block>[] nextBoard;
	private JPanel[][][] nextGrid;
	private JPanel mainNextPanel;
	private JPanel otherNextPanels;
	private JPanel[] nextPanels;
	private JLabel nextLabel;
	
	private JLabel scoreLabel;
    private JLabel levelLabel;
    private JLabel linesClearedLabel;
    
	private JFrame frame;
	private ArrowListener listener;

	// Constructs a new display for displaying the given board
	public BlockDisplay(MyBoundedGrid<Block> board, MyBoundedGrid<Block> holdB, MyBoundedGrid<Block>[] nextB)
	{
		this.board = board;
		grid = new JPanel[board.getNumRows()][board.getNumCols()];
		
		holdBoard = holdB;
		holdGrid = new JPanel[holdBoard.getNumRows()][holdBoard.getNumCols()];
		
		nextBoard = nextB;
	    nextGrid = new JPanel[nextBoard.length][holdBoard.getNumRows()][holdBoard.getNumCols()];

        //Schedule a job for the event-dispatching thread:
        //creating and showing this application's GUI.
        SwingUtilities.invokeLater(new Runnable()
        {
            public void run()
            {
                createAndShowGUI();
            }
        });

		//Wait until display has been drawn
        try
        {
        	while (frame == null || !frame.isVisible())
        		Thread.sleep(1);
		}
		catch(InterruptedException e)
		{
			e.printStackTrace();
			System.exit(1);
		}
	}

    /**
     * Create the GUI and show it.  For thread safety,
     * this method should be invoked from the
     * event-dispatching thread.
     */
    private void createAndShowGUI()
    {
        //Create and set up the window.
        frame = new JFrame();
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.addKeyListener(this);
        frame.setFocusable(true);
        frame.setSize(415,485);
        frame.setLayout(null); //makes frame absolute control
        
        //Main board
        createAndAddMain();       
        //Hold board
        createAndAddHold();
        //Next board
        createAndAddNext();
        
        createAndAddScore();
        createAndAddLinesCleared();
        
		//Show the board
		showMain();

        //Display the window.
		frame.setVisible(true);
    }
    
    /**
     * Method: createAndAddMain()
     * Usage: createAndAddMain()
     * -------------------------
     * makes and adds the mainGrid gui and its border and label
     */
    private void createAndAddMain()
    {
        mainPanel = new JPanel();
        mainPanel.setLayout(new GridLayout(board.getNumRows(), board.getNumCols()));
        mainPanel.setLocation(100,40+10);
        mainPanel.setSize(200,400);
        mainPanel.setBorder(BorderFactory.createLineBorder(Color.ORANGE));
        for (int row = 0; row < grid.length; row++)
            for (int col = 0; col < grid[row].length; col++)
            {
                grid[row][col] = new JPanel();
                grid[row][col].setBackground(BACKGROUND);
                grid[row][col].setPreferredSize(new Dimension(20, 20));
                mainPanel.add(grid[row][col]);
            }
        frame.add(mainPanel);
    }
    
    /**
     * Method: createAndAddHold()
     * Usage: createAndAddHold();
     * --------------------------------------
     * makes and adds the holdGrid gui and its border and label
     */
    private void createAndAddHold()
    {
        holdPanel = new JPanel();
        holdPanel.setLocation(18,85+10);
        holdPanel.setSize(18*holdBoard.getNumRows(),18*holdBoard.getNumCols());
        holdPanel.setLayout(new GridLayout(holdBoard.getNumRows(), holdBoard.getNumCols()));     
        for (int row = 0; row < holdGrid.length; row++)
            for (int col = 0; col < holdGrid[row].length; col++)
            {
                holdGrid[row][col] = new JPanel();
                holdGrid[row][col].setBackground(BACKGROUND);
                holdGrid[row][col].setPreferredSize(new Dimension(18,18));
                holdPanel.add(holdGrid[row][col]);
            }
        
        //border
        holdPanel.setBorder(BorderFactory.createLineBorder(Color.ORANGE, 2, true));       
        holdLabel = new JLabel();
        holdLabel.setFont(new Font("MV Boli", Font.PLAIN, 24));
        holdLabel.setText("HOLD");
        holdLabel.setForeground(Color.MAGENTA);
        holdLabel.setLocation(20,50+10);
        holdLabel.setSize(18*4,35);
        frame.add(holdLabel);
//        holdPanel.setLocation(15,65+10);
//        holdPanel.setSize(18*holdBoard.getNumRows()+10,18*holdBoard.getNumCols()+25);
//        holdPanel.setBorder(BorderFactory.createTitledBorder(BorderFactory.createLineBorder(Color.ORANGE), "HOLD"));
        
        frame.add(holdPanel);
    }
    
    /**
     * Method: createAndAddNext()
     * Usage: createAndAddNext()
     * ----------------------------
     * makes and adds the nextGrids gui and its border and label
     */
    private void createAndAddNext()
    {
        mainNextPanel = new JPanel();
        mainNextPanel.setLayout(new GridLayout(holdBoard.getNumRows(), holdBoard.getNumCols()));
        mainNextPanel.setLocation(308,85+10);
        mainNextPanel.setSize(18*4,18*4);
        mainNextPanel.setBorder(BorderFactory.createLineBorder(Color.ORANGE, 2, true));
        for (int row = 0; row < nextGrid[0].length; row++)
            for (int col = 0; col < nextGrid[0][row].length; col++)
            {
                nextGrid[0][row][col] = new JPanel();
                nextGrid[0][row][col].setBackground(BACKGROUND);
                nextGrid[0][row][col].setPreferredSize(new Dimension(18,18));
                mainNextPanel.add(nextGrid[0][row][col]);
            }
        frame.add(mainNextPanel);   
        
        otherNextPanels = new JPanel();
        otherNextPanels.setBackground(Color.BLACK);
        otherNextPanels.setSize(56,48*4+25);
        otherNextPanels.setLocation(317,165+10);
        otherNextPanels.setBorder(BorderFactory.createLineBorder(Color.ORANGE, 2));
        nextPanels = new JPanel[5];
        for (int i=1; i<nextGrid.length; i++)
        {
            nextPanels[i] = new JPanel();
            nextPanels[i].setLayout(new GridLayout(holdBoard.getNumRows(), holdBoard.getNumCols()));
            nextPanels[i].setSize(48,48);
            nextPanels[i].setLocation(4,(i-1)*48);
            for (int row = 0; row < nextGrid[i].length; row++)
                for (int col = 0; col < nextGrid[i][row].length; col++)
                {
                    nextGrid[i][row][col] = new JPanel();
                    nextGrid[i][row][col].setBackground(BACKGROUND);
                    nextGrid[i][row][col].setPreferredSize(new Dimension(12,12));
                    nextPanels[i].add(nextGrid[i][row][col]);
                }
            otherNextPanels.add(nextPanels[i]);
        }
        frame.add(otherNextPanels);
        
        nextLabel = new JLabel();
        nextLabel.setFont(new Font("MV Boli", Font.PLAIN, 24));
        nextLabel.setText("NEXT");
        nextLabel.setForeground(Color.MAGENTA);
        nextLabel.setLocation(310,50+10);
        nextLabel.setSize(18*4,35);
        frame.add(nextLabel);
    }
    
    /**
     * Method: createAndAddScore()
     * Usage: createAndAddScore()
     * ------------------------------
     * makes and adds the score and level gui and its border and label
     */
    private void createAndAddScore()
    {
        scoreLabel = new JLabel();
        scoreLabel.setFont(new Font("MV Boli", Font.BOLD, 32));
        scoreLabel.setHorizontalAlignment(SwingConstants.RIGHT);
        scoreLabel.setForeground(Color.MAGENTA);
        scoreLabel.setBorder(BorderFactory.createTitledBorder(BorderFactory.createLineBorder(Color.ORANGE), "SCORE"));
        scoreLabel.setSize(400,50);//180,50);
        scoreLabel.setLocation(0,0);//122,0);
        
        scoreLabel.setText(""+10000);
        frame.add(scoreLabel);
        
        levelLabel = new JLabel();
        levelLabel.setFont(new Font("MV Boli", Font.BOLD, 32));
        levelLabel.setHorizontalAlignment(SwingConstants.RIGHT);
        levelLabel.setForeground(Color.MAGENTA);
        levelLabel.setBorder(BorderFactory.createTitledBorder(BorderFactory.createLineBorder(Color.ORANGE), "LEVEL"));
        levelLabel.setSize(90,50);
        levelLabel.setLocation(5,200);
        
        levelLabel.setText("" + 1);
        frame.add(levelLabel);
    }
    
    /**
     * Method: createAndAddlinesClearedLabel()
     * Usage: createAndAddlinesClearedLabel()
     * -----------------------------------
     * makes and adds the linesClearedLabel gui and its border and label
     */
    private void createAndAddLinesCleared()
    {
        linesClearedLabel = new JLabel();
        linesClearedLabel.setFont(new Font("MV Boli", Font.BOLD, 32));
        linesClearedLabel.setHorizontalAlignment(SwingConstants.RIGHT);
        linesClearedLabel.setForeground(Color.MAGENTA);
        linesClearedLabel.setBorder(BorderFactory.createTitledBorder(BorderFactory.createLineBorder(Color.ORANGE), "Cleared"));
        linesClearedLabel.setSize(90,50);
        linesClearedLabel.setLocation(5,280);
        
        linesClearedLabel.setText("" + 0);
        frame.add(linesClearedLabel);
    }

	/**
	 * Method: showMain()
	 * Usage: BlockDisplay.showMain();
	 * -------------------------------
	 * repaints the main game board
	 */
	public void showMain()
	{
		for (int row = 0; row < grid.length; row++)
			for (int col = 0; col < grid[row].length; col++)
			{
				Location loc = new Location(row, col);

				Block square = board.get(loc);

				if (square == null)
				{
					grid[row][col].setBackground(BACKGROUND);
					grid[row][col].setBorder(null);
				}
				else if (square.getColor()==BACKGROUND) //shadow block
                {
                    grid[row][col].setBackground(square.getColor());
                    grid[row][col].setBorder(BorderFactory.createLineBorder(Color.GRAY));
                }
				else
				{
					grid[row][col].setBackground(square.getColor());
					grid[row][col].setBorder(BorderFactory.createBevelBorder(0));
				}
			}
	}
	
	/**
     * Method: showHold()
     * Usage: BlockDisplay.showHold();
     * -------------------------------
     * repaints the hold board
     */
	public void showHold()
    {
        for (int row = 0; row < holdGrid.length; row++)
            for (int col = 0; col < holdGrid[row].length; col++)
            {
                Location loc = new Location(row, col);

                Block square = holdBoard.get(loc);

                if (square == null)
                {
                    holdGrid[row][col].setBackground(BACKGROUND);
                    holdGrid[row][col].setBorder(null);
                }
                else
                {
                    holdGrid[row][col].setBackground(square.getColor());
                    holdGrid[row][col].setBorder(BorderFactory.createBevelBorder(0));
                }
            }  
    }
	
	/**
     * Method: showHold()
     * Usage: BlockDisplay.showNext();
     * -------------------------------
     * repaints the next board
     */
	public void showNext()
    {
	    for (int i=0; i<nextGrid.length; i++)
            for (int row = 0; row < nextGrid[i].length; row++)
                for (int col = 0; col < nextGrid[i][row].length; col++)
                {
                    Location loc = new Location(row, col);
    
                    Block square = nextBoard[i].get(loc);
    
                    if (square == null)
                    {
                        nextGrid[i][row][col].setBackground(BACKGROUND);
                        nextGrid[i][row][col].setBorder(null);
                    }
                    else
                    {
                        nextGrid[i][row][col].setBackground(square.getColor());
                        nextGrid[i][row][col].setBorder(BorderFactory.createBevelBorder(0));
                    }
                }    
    }
	
	/**
	 * Method: setLevel(level)
	 * Usage: display.setLevel(level);
	 * -------------------------------
	 * @param lvl - level to be shown
	 */
	public void setLevel(int lvl)
	{
	    levelLabel.setText("" + lvl);
	}
	
	/**
	 * Method: setScore(int)
	 * Usage: display.setScore(1000);
	 * -------------------------------
	 * sets the score
	 * @param score - the new score
	 */
	public void setScore(String score)
	{
	    scoreLabel.setText(score);
	}
	
	/**
	 * Method: setlinesClearedLabel()
	 * Usage: setlinesClearedLabel()
	 * --------------------------
	 * sets the linesClearedLabel label
	 * @param linesClearedLabel - the new linesClearedLabel
	 */
	public void setLinesCleared(int lines)
	{
	    linesClearedLabel.setText("" + lines);
	}
	
	/**
	 * Method: randomColor()
	 * Usage: setColor(randomColor);
	 * ---------------------------------
	 * @return random color in the rainbow
	 */
	private Color randomColor()
    {
        int rand = (int)(Math.random()*8);
        if (rand==0) return Color.RED;
        else if (rand==1) return Color.ORANGE;
        else if (rand==2) return Color.YELLOW;
        else if (rand==3) return Color.GREEN;
        else if (rand==4) return Color.BLUE;
        else if (rand==5) return Color.MAGENTA;
        else if (rand==6) return Color.CYAN;
        else if (rand==7) return Color.PINK;
        return Color.BLACK;
    }

	/**
	 * 
	 * @param title
	 */
	public void setTitle(String title)
	{
		frame.setTitle(title);
	}

	public void keyTyped(KeyEvent e)
	{
	}

	public void keyReleased(KeyEvent e)
	{
	}

	/**
	 * Method: keyPressed()
	 * Usage: 
	 * ----------------------------
	 * when a key is pressed on an element that is focused and has a keyListener
	 * keyPressed calls the correct method according to the pressed key
	 */
	public void keyPressed(KeyEvent e)
	{
		if (listener == null)
			return;
		int code = e.getKeyCode();
		if (code == KeyEvent.VK_LEFT)
			listener.leftPressed();
		else if (code == KeyEvent.VK_RIGHT)
			listener.rightPressed();
		else if (code == KeyEvent.VK_DOWN)
			listener.downPressed();
		else if (code == KeyEvent.VK_UP)
			listener.upPressed();
		else if (code == KeyEvent.VK_SPACE)
		    listener.spacePressed();
		else if (code == KeyEvent.VK_SHIFT)
		    listener.shiftPressed();
	}

	/**
	 * Method: setArrowListener(ArrowListner)
	 * Usage: BlockDisplay.setArrowListener(Tetris)
	 * ---------------------------------------------
	 * switches the arrowListner of to the given one
	 * @param listener - the given arrowListener
	 */
	public void setArrowListener(ArrowListener listener)
	{
		this.listener = listener;
	}
}