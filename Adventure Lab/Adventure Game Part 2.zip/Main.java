
public class Main
{

    /**
     * @param args
     */
    public static void main(String[] args)
    {
        CommandWords.initialize(null);
        Game theGame = new Game();
        theGame.play();

    }

}
